# qq_fanghong

## 引言

因为`github.io`自身就是自带QQ、微信防红的域名，所以是用来做防红接口的不错材料。

## 使用方法

进入该网址：[qqred.qian.blue](https://qqred.qian.blue)
